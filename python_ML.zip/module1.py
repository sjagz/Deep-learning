def my_sum(a,b):  # 함수선언
    return a*b

pi=3.141592  #변수선언